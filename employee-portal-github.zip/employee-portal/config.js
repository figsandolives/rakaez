export const CONFIG={
  firebase:{apiKey:"AIzaSyC5aYsmT1qUJd5D8GVh5WlIlLeiT35t8WQ",authDomain:"hrpro-f80e7.firebaseapp.com",databaseURL:"https://hrpro-f80e7-default-rtdb.firebaseio.com",projectId:"hrpro-f80e7",storageBucket:"hrpro-f80e7.firebasestorage.app",messagingSenderId:"999134303706",appId:"1:999134303706:web:a9f0b7bacb6ba796f55ce3",measurementId:"G-JFC4SPKXDK"}
};
