const CACHE_NAME = "rakaez-fingerprint-v3";
const APP_SHELL = [
  "./",
  "./index.html",
  "./style.css",
  "./login-phone.css",
  "./app.js",
  "./config.js",
  "./fingerprint-icon-192.png",
  "./fingerprint-icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
